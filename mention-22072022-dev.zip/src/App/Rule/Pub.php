<?php

namespace App\Rule;

interface Pub
{
	public function container($option);
}
