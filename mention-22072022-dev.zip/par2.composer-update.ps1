cd src
composer update
exit