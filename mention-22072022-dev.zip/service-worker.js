// Service Worker is PWA controller. This file is not complete, but it paves the way for important features such as Push Notification in the future.
// For now, the application can still be installed on Mobile and PC.

self.addEventListener('install', function () {

});

self.addEventListener("activate", event => {

});

self.addEventListener('fetch', function (event) {

});